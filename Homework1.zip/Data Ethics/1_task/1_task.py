class Solution:
    def findLengthOfLCIS(self, nums: List[int]) -> int:
        ans = 1
        tnt = 1
        for i, x in enumerate(nums[1:]):
            if nums[i] < x:
                tnt += 1
                ans = max(ans, tnt)
            else:
                tnt = 1
        return ans